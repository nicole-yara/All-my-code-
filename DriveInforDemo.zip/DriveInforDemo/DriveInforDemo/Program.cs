﻿using System;
using System.IO;

namespace DriveInforDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            DriveInfo[] drives = DriveInfo.GetDrives();
            foreach(DriveInfo drive in drives)
            {
                Console.WriteLine("Drive name : {0}", drive.Name);
                Console.WriteLine("Drive type : {0}", drive.DriveType);
                //Check if srive is connected and ready.
                {
                    Console.WriteLine("Free space :{0}", drive.TotalSize);
                    Console.WriteLine("Drive format:{0}", drive.DriveFormat);
                    Console.WriteLine("Volume lebel :{0}", drive.VolumeLabel);

                }

            }
        }
    }
}
