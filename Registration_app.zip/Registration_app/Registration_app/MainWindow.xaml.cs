﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;

namespace Registration_app
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\nicol\source\repos\Registration_app\Registration_app\User.mdf;Integrated Security=True;");
        SqlCommand cmd = new SqlCommand();

        private void registration_btn_Click(object sender, RoutedEventArgs e)
        {
            {
                if (username1_box.Text == "" && password1_box.Password == "" && confirm_box.Password == "")
                {
                    MessageBox.Show("Username and Password fields are empty", "Registration Failed");
                }
                else if (password1_box.Password == confirm_box.Password)
                {

                    string register = "INSERT INTO [dbo].[User](Username,Password) VALUES (@Username,@Password)";
                    cmd.Parameters.AddWithValue("@Username", username1_box.Text);
                    cmd.Parameters.AddWithValue("@Password", password1_box.Password);
                    cmd = new SqlCommand(register, con);
                    con.Open();
                    
                    con.Close();

                    username1_box.Text = "";
                    password1_box.Password = "";
                    confirm_box.Password = "";

                    MessageBox.Show("Your Account has been Successfully Created", "Registration Success");
                }
                else
                {
                    MessageBox.Show("Passwords does not match, Please Re_enter", "Registration Failed");
                    password1_box.Password = "";
                    confirm_box.Password = "";
                    password1_box.Focus();

                }


            }
        }

       

        private void clear_btn_Click(object sender, RoutedEventArgs e)
        {
            username1_box.Text = "";
            password1_box.Password = "";
            confirm_box.Password = "";
            username1_box.Focus();
        }

        

        private void back_login_btn_Click(object sender, RoutedEventArgs e)
        {
            login objlogin = new login();
            this.Content = objlogin;
        }
    }
    }
