﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using Calculations;

namespace Registration_app
{
    /// <summary>
    /// Interaction logic for modules.xaml
    /// </summary>
    public partial class modules : Page
    {
        public modules()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\nicol\source\repos\Registration_app\Registration_app\User.mdf;Integrated Security=True;");
        SqlCommand cmd = new SqlCommand();
        private void view_btn_Click(object sender, RoutedEventArgs e)
        {
            if (module_name_box.Text == "" && module_code_box.Text == "" && credits_box.Text == "" && hours_box.Text == "")
            {
                MessageBox.Show("There is and empty field", "View Failed");

            }
            string modules = "INSERT INTO [dbo].[Modules](Module_code,Module_name,No.of_credits,Class_hours) VALUES (@Module_name,@No.of credits, Class_hours)";
            cmd.Parameters.AddWithValue("@Module_code", module_code_box.Text);
            cmd.Parameters.AddWithValue("@Module_name", module_name_box.Text);
            cmd.Parameters.AddWithValue("@No.of_credits", int.Parse(credits_box.Text));
            cmd.Parameters.AddWithValue("@Class_hours", int.Parse(hours_box.Text));
            cmd = new SqlCommand(modules, con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

            module_code_box.Text = "";
            module_name_box.Text = "";
            credits_box.Text = "";
            hours_box.Text = "";

            MessageBox.Show(module_code_box.Text, module_name_box.Text);

        }

       

        private void clear_btn_Click(object sender, RoutedEventArgs e)
        {
            module_code_box.Text = "";
            module_name_box.Text = "";
            credits_box.Text = "";
            hours_box.Text = "";
            module_code_box.Focus();
        }
    }
}
