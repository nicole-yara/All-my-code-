﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;

namespace Registration_app
{
    /// <summary>
    /// Interaction logic for login.xaml
    /// </summary>
    public partial class login : Page
    {
        public login()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\nicol\source\repos\Registration_app\Registration_app\User.mdf;Integrated Security=True;");
        SqlCommand cmd = new SqlCommand();
        

       

       

        private void clear_btn_Click(object sender, RoutedEventArgs e)
        {
            username2_box.Text = "";
            password2_box.Password = "";
            username2_box.Focus();
        }

        private void login_btn_Click(object sender, RoutedEventArgs e)
        {
            con.Open();
            string login = "SELECT * FROM [dbo].[Table] WHERE username = '" + username2_box.Text + "' and password = '" + password2_box.Password + "'";
            cmd = new SqlCommand(login, con);


            if (username2_box.Text == "nicole" && password2_box.Password == "123") 
            {
                modules objomodules = new modules();
                this.Content = objomodules;
                
            }
            else
            {
                MessageBox.Show("Inavlid Username or Password, Please Try Again", "Login Failed");
                username2_box.Text = "";
                password2_box.Password = "";
                username2_box.Focus();
                con.Close();
            }

        }

        private void create_account_btn_Click(object sender, RoutedEventArgs e)
        {
            MainWindow objmain = new MainWindow();
            this.Content = objmain;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            modules objomodules = new modules();
            this.Content = objomodules;
        }
    }
    }

