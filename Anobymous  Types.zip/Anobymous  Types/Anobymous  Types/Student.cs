﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Anobymous__Types
{
    public class Student
    {
        public int StudentID { get; set; }
        public string StudentName { get; set; }
        public int age { get; set; }
    }
}