﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Anobymous__Types
{
    class Program
    {
        static void Main(string[] args)
        {
            IList<Student> studentList = new List<Student>() {
            new Student() { StudentID = 1, StudentName = "Aaron", age = 22 },
            new Student() { StudentID = 2, StudentName = "Luka",  age = 21 },
            new Student() { StudentID = 3, StudentName = "Chole",  age = 18 },
            new Student() { StudentID = 4, StudentName = "Anna" , age = 20  },
            new Student() { StudentID = 5, StudentName = "Yara" , age = 21 }
        };

            var students = from s in studentList

                           select new { Id = s.StudentID, Name = s.StudentName };

            foreach (var stud in students)
                Console.WriteLine(stud.Id + "-" + stud.Name);
        }
    }

}