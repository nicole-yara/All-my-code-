﻿using System;
using System.IO;

namespace DirectoryInfodemo
{
    class Program
    {
        static void Main(string[] args)
        {
            DirectoryInfo dr = new DirectoryInfo(@"C:\Windows");
           dr.Create ();
            Console.WriteLine("Just having fun with directory info");
            Console.WriteLine("***** Directory info *****");
            Console.WriteLine("Fullname :{0} ", dr.FullName);
            Console.WriteLine("name", dr.Name);
            Console.WriteLine("Parent : {0}", dr.Parent);
            Console.WriteLine("Creation  time :{0}" , dr.CreationTime);
            Console.WriteLine("Last accessed : {0}",dr.LastAccessTime);
            Console.WriteLine("Last written : {0}",dr.LastWriteTime);
            Console.WriteLine("Attributes : {0}",dr.Attributes);
            Console.WriteLine("Root : {0}",dr.Root);
            Console.ReadLine();





        }
    }
}
