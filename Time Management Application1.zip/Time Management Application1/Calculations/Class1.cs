﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculations
{
    public class Class1
    {
        int selfStudy;
        int tenTimes;
        string ClassHour;
        string NumberofWeeks;
        string NumberofCredits;

        //  int i1 = Convert.ToInt32(ClassHour);
        //int i2 = Convert.ToInt32(NumberofWeeks);
        // int i3 = Convert.ToInt32(NumberofCredits);

        // tenTimes = 10;


        //   selfStudy = i3* tenTimes / i2 - i1;

        //  MessageBox.Show(selfStudy.ToString());
    }
}
