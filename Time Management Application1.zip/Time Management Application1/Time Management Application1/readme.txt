************************************************************
************************************************************
*  Installation Readme for Time Management Application1 
*
*  Refer to the system requirements for the operating systems
*  supported by the Loan program.
*
************************************************************
************************************************************

************************************************************
*  CONTENTS OF THIS DOCUMENT
************************************************************

This document contains the following sections:

1.  Overview
2.  System Requirements
3.  Installing the Software


************************************************************
* 1.  OVERVIEW
************************************************************
The user friendly application is used for ,the time management lets a user to enter 
their module information such as start time of the semester, module name, module code,
number of weeks and number of credits. Which will present the users with the study time 
the have left for the week for each module. 


************************************************************
* 2.  SYSTEM REQUIREMENTS
************************************************************


  The system must be running on one of the following
    operating systems:
   

 The system should contain at least the minimum system 
    memory required by the operating system.



************************************************************
* 3.  INSTALLING THE SOFTWARE
************************************************************

1. Unzipp the [Time Management Application]
    Right click on folder and then select extract all

2. Open File on Visual Studio
     - Select [Time Management Application1]
     - Select [Time Management Application1.sln]

3. Run Code 
after running the code the users will have to input all their information 
and for the code having a invalid pop up user should just press the ok and the 
program will work.The user will enter the information and add the calculation
and it will show the list.



************************************************************

************************************************************
