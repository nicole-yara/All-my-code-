﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Time_Management_Application1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        //Users will have to input their information into the textbok and this is where the actions of the code will be made
        private void start_semester_box_TextChanged(object sender, TextChangedEventArgs e)
        {
            string StartDateSemester = this.start_semester_box.Text;

            //Validating user input 
            if (StartDateSemester != "")
            {

            }
            else
            {
                MessageBox.Show("Inavlid user input has been entered \n please enter numbers only");
            }
        }

        private void code_box_TextChanged(object sender, TextChangedEventArgs e)
        {
            string ModuleCode = this.code_box.Text;

            //Validating user input 
            if (ModuleCode != "")
            {

            }
            else
            {
                MessageBox.Show("Inavlid user input has been entered ");
            }
        }

        private void module_name_box_TextChanged(object sender, TextChangedEventArgs e)
        {
            string ModuleName = this.module_name_box.Text;

            //Validating user input 
            if (ModuleName != "")
            {

            }
            else
            {
                MessageBox.Show("Inavlid user input has been entered \n please enter module name");
            }
        }

        private void class_hour_box_TextChanged(object sender, TextChangedEventArgs e)
        {
            string ClassHours = this.class_hour_box.Text;
            double number_4;
            //Validating user input 
            if (ClassHours != "")
            {
                number_4 = Double.Parse(ClassHours);
            }
            else
            {
                MessageBox.Show("Inavlid user input has been entered \n please enter numbers only");
            }
        }

        private void no_of_weeks_boxs_TextChanged(object sender, TextChangedEventArgs e)
        {
            string NumberofWeeks = this.no_of_weeks_boxs.Text;
            double number_5;
            //Validating user input 
            if (NumberofWeeks != "")
            {
                number_5 = Double.Parse(NumberofWeeks);
            }
            else
            {
                MessageBox.Show("Inavlid user input has been entered \n please enter numbers only");
            }
        }

        private void no_of_credits_box_TextChanged(object sender, TextChangedEventArgs e)
        {
            string NumberofCredits = this.no_of_credits_box.Text;
            double number_6;
            //Validating user input 
            if (NumberofCredits != "")
            {
                number_6 = Double.Parse(NumberofCredits);
            }
            else
            {
                MessageBox.Show("Inavlid user input has been entered \n please enter numbers only");
            }
        }
        public string StartDateSemester { get; set; }
        public string ModuleCode { get; set; }
        public string ModuleName { get; set; }
        public int NumberofWeeks { get; set; }
        public int NumberofCredits { get; set; }
        public int selfStudy { get; set; }

        private void add_btn_Click_1(object sender, RoutedEventArgs e)
        {
            //adding list for modules
            if (start_semester_box.Text != "" && code_box.Text != "" && module_name_box.Text != "" && class_hour_box.Text != ""
                 && no_of_weeks_boxs.Text != "" && no_of_credits_box.Text != "")
            {
                List<string> moduleList = new List<string>();
                moduleList.Add(this.start_semester_box.Text);
                start_semester_box.Focus();
                start_semester_box.Clear();
                moduleList.Add(this.code_box.Text);
                code_box.Focus();

                moduleList.Add(this.module_name_box.Text);
                module_name_box.Focus();

                moduleList.Add(this.class_hour_box.Text);
                class_hour_box.Focus();

                moduleList.Add(this.no_of_weeks_boxs.Text);
                no_of_weeks_boxs.Focus();

                moduleList.Add(this.no_of_credits_box.Text);
                no_of_credits_box.Focus();
                // when the user clicks add button the calculation will be added and a new module will be add to the list 
                int selfStudy;
                int tenTimes;
                string ClassHour = this.class_hour_box.Text;
                string NumberofWeeks = this.no_of_weeks_boxs.Text;
                string NumberofCredits = this.no_of_credits_box.Text;

                int i1 = Convert.ToInt32(ClassHour);
                int i2 = Convert.ToInt32(NumberofWeeks);
                int i3 = Convert.ToInt32(NumberofCredits);

                tenTimes = 10;


                selfStudy = i3 * tenTimes / i2 - i1;

                MessageBox.Show(selfStudy.ToString());



            }


        }

    }
}
    
